## Generated Story 1887858919291646228
* restaurant_search{"location": "muzzafarpur"}
    - slot{"location": "muzzafarpur"}
    - slot{"location": null}
    - utter_goodbye
    - export
    

## Generated Story 8118643156683928286
* restaurant_search{"cuisine": "italian", "location": "delhi", "budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - slot{"cuisine": "italian"}
    - slot{"location": "delhi"}
    - action_restaurant
    - slot{"location": "delhi"}
    - utter_ask_email
* goodbye
    - utter_goodbye
    - export

## Generated Story -886555248039309322
* greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - action_restaurant
    - slot{"location": "kolkata"}
    - utter_ask_email
* goodbye
    - utter_goodbye
    - export

## Generated Story -2480997230767208211
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - action_restaurant
    - slot{"location": "delhi"}
    - utter_ask_email
* send_mail
    - utter_ask_emailid
* send_mail{"emailid": "gautam.jha911@gmail.com"}
    - slot{"emailid": "gautam.jha911@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export

## Generated Story 4100907500014439301
* greet
    - utter_greet
* restaurant_search{"location": "kochi"}
    - slot{"location": "kochi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* restaurant_search{"budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - action_restaurant
    - slot{"location": "kochi"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "gautam.jha911@gmail.com"}
    - slot{"emailid": "gautam.jha911@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export

## Generated Story -2854345149628658739
* greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - utter_ask_cuisine
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_budget
* restaurant_search{"budget": "less than 300"}
    - slot{"budget": "less than 300"}
    - action_restaurant
    - slot{"location": "chennai"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export

## Generated Story 7400846884316438101
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "goa"}
    - slot{"location": "goa"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"budget": "less than 300"}
    - slot{"budget": "less than 300"}
    - action_restaurant
    - slot{"location": "goa"}
    - utter_ask_email
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export


## Generated Story 1871716934601214609
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "visakhapatnam"}
    - slot{"location": "visakhapatnam"}
    - slot{"location": "visakhapatnam"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_budget
* restaurant_search{"budget": "300 or 700"}
    - slot{"budget": "300 or 700"}
    - action_restaurant
    - slot{"location": "visakhapatnam"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export

## Generated Story 5672546252648477646
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - action_restaurant
    - slot{"location": "hyderabad"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export

## Generated Story 458693754883904173
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* restaurant_search{"budget": "300 or 700"}
    - slot{"budget": "300 or 700"}
    - action_restaurant
    - slot{"location": "mumbai"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - action_send_email
    - action_send_email
    - utter_goodbye
    - export

## Generated Story -5135523164018961780
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_budget
* restaurant_search{"budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - action_restaurant
    - slot{"location": "bangalore"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "kalla.raviteja.123@gmail.com"}
    - slot{"emailid": "kalla.raviteja.123@gmail.com"}
    - action_send_email
    - utter_goodbye
    - export

## Generated Story -1295604620412695981
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "300 or 700"}
    - slot{"budget": "300 or 700"}
    - action_restaurant
    - slot{"location": "kolkata"}
    - utter_ask_email
* goodbye
    - utter_goodbye
    - export

        
## Generated Story 1578045798293583351
* restaurant_search{"cuisine": "north indian", "location": "kochi", "budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - slot{"cuisine": "north indian"}
    - slot{"location": "kochi"}
    - action_restaurant
    - slot{"location": "kochi"}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "gautam.jha911@gmail.com"}
    - slot{"emailid": "gautam.jha911@gmail.com"}
    - action_send_email
    - export

## Generated Story -6867994250667647956
* restaurant_search
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "lucknow"}
    - slot{"location": "lucknow"}
    - utter_ask_cuisine
* restaurant_search{"location": "north"}
    - slot{"location": "north"}
* restaurant_search{"cuisine": "north indian", "location": "lucknow"}
    - slot{"cuisine": "north indian"}
    - slot{"location": "lucknow"}
    - utter_ask_budget
* restaurant_search{"budget": "greater than 700"}
    - slot{"budget": "greater than 700"}
    - action_restaurant
    - slot{"location": "lucknow"}
* restaurant_search{"location": "1"}
    - slot{"location": "1"}
    - utter_ask_email
* goodbye
    - utter_goodbye
    - export

