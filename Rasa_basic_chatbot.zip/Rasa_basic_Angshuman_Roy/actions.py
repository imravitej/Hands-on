from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core.actions.action import Action
from rasa_core.events import SlotSet
import zomatopy
import json
# Import the email modules we'll need
from email.message import EmailMessage
# Import smtplib for the email sending function
import smtplib


emailContent = ""
tier1=['ahmedabad', 'bangalore', 'chennai',
                       'delhi', 'hyderabad', 'kolkata', 'mumbai', 'pune']
tier2=['agra', 'ajmer', 'aligarh', 'allahabad', 'amravati', 'amritsar', 'asansol', 'aurangabad', 'bareilly', 'belgaum', 'bhavnagar', 'bhiwandi', 'bhopal', 'bhubaneswar', 'bikaner', 'bokaro steel city', 'chandigarh', 'coimbatore', 'cuttack', 'dehradun', 'dhanbad', 'durg-bhilai nagar', 'durgapur', 'erode', 'faridabad', 'firozabad', 'ghaziabad', 'gorakhpur', 'gulbarga', 'guntur', 'gurgaon', 'guwahati', 'gwalior', 'hubli-dharwad', 'indore', 'jabalpur', 'jaipur', 'jalandhar', 'jammu', 'jamnagar', 'jamshedpur', 'jhansi', 'jodhpur', 'kannur', 'kanpur', 'kakinada', 'kochi',
                       'kottayam', 'kolhapur', 'kollam', 'kota', 'kozhikode', 'kurnool', 'lucknow', 'ludhiana', 'madurai', 'malappuram', 'mathura', 'goa', 'mangalore', 'meerut', 'moradabad', 'mysore', 'nagpur', 'nanded', 'nashik', 'nellore', 'noida', 'palakkad', 'patna', 'pondicherry', 'raipur', 'rajkot', 'rajahmundry', 'ranchi', 'rourkela', 'salem', 'sangli', 'siliguri', 'solapur', 'srinagar', 'sultanpur', 'surat', 'thiruvananthapuram', 'thrissur', 'tiruchirappalli', 'tirunelveli', 'tiruppur', 'ujjain', 'vijayapura', 'vadodara', 'varanasi', 'vasai-virar city', 'vijayawada', 'visakhapatnam', 'warangal']

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_restaurant'

	def run(self, dispatcher, tracker, domain):
		config={ "user_key":"889dba1ee3b44e5edf8b27539733c5d7"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budget = tracker.get_slot('budget')
		location_detail=zomato.get_location(loc, 1)
		
		if (loc.lower() in [x.lower() for x in tier1+tier2]):
			response = ""
		else:
			response = "Not a valid location"		
		
		
		d1 = json.loads(location_detail)
		cuisine_dict = {"chinese":25, "mexican":73, "italian":55, "american":1 ,"south indian":85, "north indian":50}
		budget_dict = {"less than 300":1, "between 300 and 700":2, "greater than 700":3}
		#email_dict = {"yes":1,"no":0}
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		#cuisines_dict=zomato.get_cuisines(loc)
		
		if (loc.lower() in [x.lower() for x in tier1+tier2]):
			response = ""
		else:
			response = "Not a valid location"
			dispatcher.utter_message("-----"+"\n"+response)
				
		results= zomato.restaurant_search("", lat, lon, str(cuisine_dict.get(cuisine)))
		d = json.loads(results)
        
		d_rest = []
		d_rest.extend(d['restaurants'])
		d_rest_list = [d_rest_single for d_rest_single in d_rest]
		d_rest_list_sorted = sorted(d_rest_list, key=lambda k: k['restaurant']['user_rating']['aggregate_rating'], reverse=True)
		d_rest_list_sorted_top5 = d_rest_list_sorted[:5]
		#print("len(d_rest_list_sorted[:5]) - ,"+len(d_rest_list_sorted[:5]))
		d_rest_list_sorted_top10 = d_rest_list_sorted[:10]
		#print("len(d_rest_list_sorted[:10]) - ,"+len(d_rest_list_sorted[:10]))
		
		msg1=""
		msg2=""
		msg3=""
		msg4=""
	
		res=""
		res2=""
		key = str(budget_dict.get(budget))

		
		for i in range(0,len(d_rest_list_sorted_top5)):
			if(key=='1' and ((int(d_rest_list_sorted_top5[i]['restaurant']['average_cost_for_two'])) < 300)):
				msg1 = " Restaurant Name: " + d_rest_list_sorted_top5[i]['restaurant']['name'] + "\n"
				msg2 = " Restaurant locality address: " + d_rest_list_sorted_top5[i]['restaurant']['location']['address'] + "\n"
				msg3 = " Average budget for two people: " + str(d_rest_list_sorted_top5[i]['restaurant']['average_cost_for_two']) + "\n"
				msg4 = " Zomato user rating: " + str(d_rest_list_sorted_top5[i]['restaurant']['user_rating']['aggregate_rating']) + "\n"
				res =  res + "\n" + (msg1 + msg2 + msg3 + msg4) + "\n"
			elif(key=='2' and ((int(d_rest_list_sorted_top5[i]['restaurant']['average_cost_for_two']) > 300 and int(d['restaurants'][i]['restaurant']['average_cost_for_two'])) < 700)):
				msg1 = " Restaurant Name: " + d_rest_list_sorted_top5[i]['restaurant']['name'] + "\n"
				msg2 = " Restaurant locality address: " + d_rest_list_sorted_top5[i]['restaurant']['location']['address'] + "\n"
				msg3 = " Average budget for two people: " + str(d_rest_list_sorted_top5[i]['restaurant']['average_cost_for_two']) + "\n"
				msg4 = " Zomato user rating: " + str(d_rest_list_sorted_top5[i]['restaurant']['user_rating']['aggregate_rating']) + "\n"
				res =  res + "\n" + (msg1 + msg2 + msg3 + msg4) + "\n"
			elif(key=='3' and (int(d_rest_list_sorted_top5[i]['restaurant']['average_cost_for_two']) > 700)):
				msg1 = " Restaurant Name: " + d_rest_list_sorted_top5[i]['restaurant']['name'] + "\n"
				msg2 = " Restaurant locality address: " + d_rest_list_sorted_top5[i]['restaurant']['location']['address'] + "\n"
				msg3 = " Average budget for two people: " + str(d_rest_list_sorted_top5[i]['restaurant']['average_cost_for_two']) + "\n"
				msg4 = " Zomato user rating: " + str(d_rest_list_sorted_top5[i]['restaurant']['user_rating']['aggregate_rating']) + "\n"
				res =  res + "\n" + (msg1 + msg2 + msg3 + msg4) + "\n"

		for i in range(0,len(d_rest_list_sorted_top10)):
			if(key=='1' and ((int(d_rest_list_sorted_top10[i]['restaurant']['average_cost_for_two'])) < 300)):
				msg1 = " Restaurant Name: " + d_rest_list_sorted_top10[i]['restaurant']['name'] + "\n"
				msg2 = " Restaurant locality address: " + d_rest_list_sorted_top10[i]['restaurant']['location']['address'] + "\n"
				msg3 = " Average budget for two people: " + str(d_rest_list_sorted_top10[i]['restaurant']['average_cost_for_two']) + "\n"
				msg4 = " Zomato user rating: " + str(d_rest_list_sorted_top10[i]['restaurant']['user_rating']['aggregate_rating']) + "\n"
				res2 =  res2 + "\n" + (msg1 + msg2 + msg3 + msg4) + "\n"
			elif(key=='2' and ((int(d_rest_list_sorted_top10[i]['restaurant']['average_cost_for_two']) > 300 and int(d['restaurants'][i]['restaurant']['average_cost_for_two'])) < 700)):
				msg1 = " Restaurant Name: " + d_rest_list_sorted_top10[i]['restaurant']['name'] + "\n"
				msg2 = " Restaurant locality address: " + d_rest_list_sorted_top10[i]['restaurant']['location']['address'] + "\n"
				msg3 = " Average budget for two people: " + str(d_rest_list_sorted_top10[i]['restaurant']['average_cost_for_two']) + "\n"
				msg4 = " Zomato user rating: " + str(d_rest_list_sorted_top10[i]['restaurant']['user_rating']['aggregate_rating']) + "\n"
				res2 =  res2 + "\n" + (msg1 + msg2 + msg3 + msg4) + "\n"
			elif(key=='3' and (int(d_rest_list_sorted_top10[i]['restaurant']['average_cost_for_two']) > 700)):
				msg1 = " Restaurant Name: " + d_rest_list_sorted_top10[i]['restaurant']['name'] + "\n"
				msg2 = " Restaurant locality address: " + d_rest_list_sorted_top10[i]['restaurant']['location']['address'] + "\n"
				msg3 = " Average budget for two people: " + str(d_rest_list_sorted_top10[i]['restaurant']['average_cost_for_two']) + "\n"
				msg4 = " Zomato user rating: " + str(d_rest_list_sorted_top10[i]['restaurant']['user_rating']['aggregate_rating']) + "\n"
				res2 =  res2 + "\n" + (msg1 + msg2 + msg3 + msg4) + "\n"


		
		global emailContent
		emailContent = emailContent+res2
		dispatcher.utter_message("\n"+"Here is the list of Top5 restuarants in " + loc + " for " + cuisine + " with average budget for 2 people " + budget + "---------"+"\n"+"\n"+res)
		return [SlotSet('location',loc)]


class ActionSendEmail(Action):
    def name(self):
        return 'action_send_email'
        
    def run(self, dispatcher, tracker, domain):
        # Get user's email id
        to_email = tracker.get_slot('emailid')

        # Get location and cuisines to put in the email
        loc = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        
        # Construct the email 'subject' and the contents.
        d_email_subj= "Top restaurants from Zomato"
        global emailContent
        #d_email_subj = "Top " + str(email_rest_count) + " " + cuisine.capitalize() + " restaurants in " + str(loc).capitalize()
        d_email_msg = "Hi there! Here are the list of Restaurant " + emailContent
        
        #d_email_msg = "This is message sent by bot"
        # Open SMTP connection to our email id.
        s = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        s.login("angshumanroygcp@gmail.com", "123java456")

        # Create the msg object
        msg = EmailMessage()

        # Fill in the message properties
        msg['Subject'] = d_email_subj
        msg['From'] = "angshumanroygcp@gmail.com"

        # Fill in the message content
        msg.set_content(d_email_msg)
        msg['To'] = to_email

        s.send_message(msg)
        s.quit()
        dispatcher.utter_message("**** Email Sent Sucessfully  :) ****")
        return []