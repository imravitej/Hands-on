from rasa_core.channels import HttpInputChannel
from rasa_core.agent import Agent
from rasa_core.interpreter import RasaNLUInterpreter
from rasa_slack_connector import SlackInput


nlu_interpreter = RasaNLUInterpreter('./models/nlu/default/restaurantnlu')
agent = Agent.load('./models/dialogue', interpreter = nlu_interpreter)

input_channel = SlackInput('xoxp-697721793623-695868065328-689546285025-c36fe2d8a524bfa0ecf83a4f222d3098', #app verification token
							'xoxb-697721793623-697744230135-JXskevvyaYTE8C9haYC2N0OZ', # bot verification token
							'j4nFkmUd4wr167QDd2LSAaUn', # slack verification token
							True)

agent.handle_channel(HttpInputChannel(5004, '/', input_channel))